package com.snowkeyboard.ime

import android.inputmethodservice.InputMethodService
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.View
import android.view.inputmethod.EditorInfo

class SnowInputMethodService : InputMethodService(), SnowKeyListener {

    private lateinit var keyboardView: SnowKeyboardView
    private var shifted = false
    private var capsLock = false
    private var lastShiftTapTime = 0L

    private val currentWord = StringBuilder()

    override fun onCreateInputView(): View {
        keyboardView = SnowKeyboardView(this)
        keyboardView.listener = this
        return keyboardView
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        shifted = false
        capsLock = false
        currentWord.clear()
        keyboardView.setShifted(false)
        keyboardView.toggleSymbols(false)
    }

    override fun onKeyPressed(key: Key) {
        vibrate()
        val ic = currentInputConnection ?: return

        when (key.code) {
            KeyCode.SHIFT -> handleShift()
            KeyCode.DELETE -> handleDelete(ic)
            KeyCode.SPACE -> handleSpace(ic)
            KeyCode.ENTER -> handleEnter(ic)
            KeyCode.SYMBOLS -> {
                keyboardView.toggleSymbols(true)
            }
            KeyCode.LETTERS -> {
                keyboardView.toggleSymbols(false)
            }
            KeyCode.LANG -> {
                // место для переключения раскладок, если их будет несколько
            }
            KeyCode.COMMA -> commitPunctuation(ic, ",")
            KeyCode.PERIOD -> commitPunctuation(ic, ".")
            else -> handleLetter(ic, key)
        }
    }

    private fun handleShift() {
        val now = System.currentTimeMillis()
        if (now - lastShiftTapTime < 350) {
            capsLock = !capsLock
            shifted = capsLock
        } else {
            shifted = !shifted
        }
        lastShiftTapTime = now
        keyboardView.setShifted(shifted)
    }

    private fun handleLetter(ic: android.view.inputmethod.InputConnection, key: Key) {
        var ch = key.code.toChar()
        if (shifted) ch = ch.uppercaseChar()

        // Автозаглавная буква в начале предложения
        val before = ic.getTextBeforeCursor(2, 0) ?: ""
        if (currentWord.isEmpty() && TextCorrector.shouldCapitalizeNext(before)) {
            ch = ch.uppercaseChar()
        }

        ic.commitText(ch.toString(), 1)

        if (ch.isLetter()) {
            currentWord.append(ch)
        } else {
            currentWord.clear()
        }

        // Если был одиночный Shift (не caps lock) — вернуться к строчным после буквы
        if (shifted && !capsLock) {
            shifted = false
            keyboardView.setShifted(false)
        }
    }

    private fun handleSpace(ic: android.view.inputmethod.InputConnection) {
        // Автокоррекция слова перед пробелом
        tryAutocorrectCurrentWord(ic)

        val before = ic.getTextBeforeCursor(2, 0) ?: ""
        if (TextCorrector.doubleSpaceToPeriod(before)) {
            // заменить "  " на ". "
            ic.deleteSurroundingText(1, 0)
            ic.commitText(". ", 1)
        } else {
            ic.commitText(" ", 1)
        }
        currentWord.clear()
    }

    private fun handleEnter(ic: android.view.inputmethod.InputConnection) {
        tryAutocorrectCurrentWord(ic)
        ic.commitText("\n", 1)
        currentWord.clear()
    }

    private fun commitPunctuation(ic: android.view.inputmethod.InputConnection, mark: String) {
        tryAutocorrectCurrentWord(ic)
        // убрать пробел перед знаком препинания, если он есть
        val before = ic.getTextBeforeCursor(1, 0)
        if (before == " ") {
            ic.deleteSurroundingText(1, 0)
        }
        ic.commitText("$mark ", 1)
        currentWord.clear()
    }

    private fun handleDelete(ic: android.view.inputmethod.InputConnection) {
        if (currentWord.isNotEmpty()) {
            currentWord.deleteCharAt(currentWord.length - 1)
        }
        ic.deleteSurroundingText(1, 0)
    }

    /** Проверяет текущее набираемое слово и при необходимости исправляет его. */
    private fun tryAutocorrectCurrentWord(ic: android.view.inputmethod.InputConnection) {
        if (currentWord.isEmpty()) return
        val word = currentWord.toString()
        val corrected = TextCorrector.correct(word) ?: return
        ic.deleteSurroundingText(word.length, 0)
        ic.commitText(corrected, 1)
        currentWord.clear()
    }

    private fun vibrate() {
        val vibrator = getSystemService(VIBRATOR_SERVICE) as? Vibrator ?: return
        if (vibrator.hasVibrator()) {
            vibrator.vibrate(VibrationEffect.createOneShot(12, VibrationEffect.DEFAULT_AMPLITUDE))
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::keyboardView.isInitialized) keyboardView.stopAnimations()
    }
}
