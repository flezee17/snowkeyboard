package com.snowkeyboard.ime

/**
 * Лёгкий модуль автокоррекции и авто-пунктуации.
 * Без интернета и без словарей-гигантов — компактный встроенный словарь
 * частотных слов + расстояние Левенштейна для поиска ближайшего совпадения.
 */
object TextCorrector {

    // Небольшой частотный словарь (можно расширять).
    private val dictionary = listOf(
        "привет", "спасибо", "пожалуйста", "конечно", "сегодня", "завтра", "вчера",
        "хорошо", "плохо", "может", "наверное", "потому", "что", "который", "которая",
        "когда", "где", "почему", "работа", "дом", "время", "человек", "жизнь",
        "думаю", "знаю", "видел", "сказал", "будет", "было", "есть", "нет", "да",
        "извини", "прости", "ладно", "давай", "скоро", "сейчас", "потом", "очень",
        "нужно", "можно", "нельзя", "просто", "вообще", "кстати", "короче", "слушай",
        "привезти", "привет", "здравствуйте", "пока", "увидимся", "люблю", "рад",
        "рада", "согласен", "согласна", "понял", "поняла", "жаль", "круто", "классно"
    )

    private fun levenshtein(a: String, b: String): Int {
        val dp = Array(a.length + 1) { IntArray(b.length + 1) }
        for (i in 0..a.length) dp[i][0] = i
        for (j in 0..b.length) dp[0][j] = j
        for (i in 1..a.length) {
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                dp[i][j] = minOf(
                    dp[i - 1][j] + 1,
                    dp[i][j - 1] + 1,
                    dp[i - 1][j - 1] + cost
                )
            }
        }
        return dp[a.length][b.length]
    }

    /**
     * Возвращает исправленное слово, если в словаре есть достаточно близкое
     * совпадение (не более 1-2 правок в зависимости от длины), иначе null.
     */
    fun correct(word: String): String? {
        if (word.length < 3) return null
        val lower = word.lowercase()
        if (dictionary.contains(lower)) return null // уже верно

        var best: String? = null
        var bestDist = Int.MAX_VALUE
        for (candidate in dictionary) {
            if (kotlin.math.abs(candidate.length - lower.length) > 2) continue
            val dist = levenshtein(lower, candidate)
            if (dist < bestDist) {
                bestDist = dist
                best = candidate
            }
        }
        val maxAllowed = if (lower.length <= 4) 1 else 2
        if (best != null && bestDist in 1..maxAllowed) {
            return matchCase(word, best)
        }
        return null
    }

    private fun matchCase(original: String, suggestion: String): String {
        return if (original.isNotEmpty() && original[0].isUpperCase()) {
            suggestion.replaceFirstChar { it.uppercaseChar() }
        } else suggestion
    }

    /** Нужно ли писать следующую букву с заглавной (начало предложения). */
    fun shouldCapitalizeNext(textBeforeCursor: CharSequence): Boolean {
        val trimmed = textBeforeCursor.toString().trimEnd(' ')
        if (trimmed.isEmpty()) return true
        val last = trimmed.last()
        return last == '.' || last == '!' || last == '?' || last == '\n'
    }

    /** Двойной пробел -> точка и пробел (как в iOS/Gboard). */
    fun doubleSpaceToPeriod(textBeforeCursor: CharSequence): Boolean {
        return textBeforeCursor.length >= 2 &&
            textBeforeCursor[textBeforeCursor.length - 1] == ' ' &&
            textBeforeCursor[textBeforeCursor.length - 2] == ' '
    }
}
