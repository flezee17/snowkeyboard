package com.snowkeyboard.ime

/** Типы специальных клавиш. Обычные буквы передаются как символ. */
object KeyCode {
    const val SHIFT = -1
    const val DELETE = -2
    const val SPACE = -3
    const val ENTER = -4
    const val SYMBOLS = -5
    const val LETTERS = -6
    const val COMMA = -7
    const val PERIOD = -8
    const val LANG = -9
}

data class Key(
    val label: String,
    val code: Int,
    val widthWeight: Float = 1f,
    val isSpecial: Boolean = false
)

/** Простая раскладка ЙЦУКЕН + цифровой/символьный слой. */
object KeyboardLayout {

    fun russianRows(shifted: Boolean): List<List<Key>> {
        val row1 = "йцукенгшщзхъ".map { it.toRowKey(shifted) }
        val row2 = "фывапролджэ".map { it.toRowKey(shifted) }
        val row3mid = "ячсмитьбю".map { it.toRowKey(shifted) }

        val row3 = mutableListOf<Key>()
        row3.add(Key(if (shifted) "⇧" else "⇧", KeyCode.SHIFT, 1.5f, true))
        row3.addAll(row3mid)
        row3.add(Key("⌫", KeyCode.DELETE, 1.5f, true))

        val row4 = listOf(
            Key("!?123", KeyCode.SYMBOLS, 1.3f, true),
            Key(",", KeyCode.COMMA, 1f, true),
            Key("RU", KeyCode.LANG, 1f, true),
            Key("␣", KeyCode.SPACE, 4f, true),
            Key(".", KeyCode.PERIOD, 1f, true),
            Key("⏎", KeyCode.ENTER, 1.5f, true)
        )

        return listOf(row1, row2, row3, row4)
    }

    fun symbolRows(): List<List<Key>> {
        val row1 = "1234567890".map { Key(it.toString(), it.code) }
        val row2 = "-/:;()₽&@\"".map { Key(it.toString(), it.code) }
        val row3 = mutableListOf<Key>()
        row3.add(Key("#+=", KeyCode.SYMBOLS, 1.5f, true))
        "*%+=#№^{}\\".forEach { row3.add(Key(it.toString(), it.code)) }
        row3.add(Key("⌫", KeyCode.DELETE, 1.5f, true))

        val row4 = listOf(
            Key("ABC", KeyCode.LETTERS, 1.3f, true),
            Key(",", KeyCode.COMMA, 1f, true),
            Key("RU", KeyCode.LANG, 1f, true),
            Key("␣", KeyCode.SPACE, 4f, true),
            Key(".", KeyCode.PERIOD, 1f, true),
            Key("⏎", KeyCode.ENTER, 1.5f, true)
        )
        return listOf(row1, row2, row3, row4)
    }

    private fun Char.toRowKey(shifted: Boolean): Key {
        val c = if (shifted) this.uppercaseChar() else this
        return Key(c.toString(), c.code)
    }
}
