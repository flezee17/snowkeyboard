package com.snowkeyboard.ime

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.random.Random

interface SnowKeyListener {
    fun onKeyPressed(key: Key)
}

/**
 * Кастомная клавиатура: рисует клавиши, анимированный снег на фоне
 * и подсветку нажатой клавиши.
 */
class SnowKeyboardView(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {

    var listener: SnowKeyListener? = null

    private var rows: List<List<Key>> = KeyboardLayout.russianRows(false)
    private var shifted = false
    var symbolsMode = false
        private set

    // геометрия клавиш для текущего кадра
    private data class KeyRect(val key: Key, val rect: RectF)
    private var keyRects: List<List<KeyRect>> = emptyList()

    // подсветка нажатой клавиши: key -> alpha (0..255), затухает со временем
    private val pressedAlpha = HashMap<Key, Int>()
    private val fadeHandler = Handler(Looper.getMainLooper())

    // --- снег ---
    private data class Snowflake(var x: Float, var y: Float, var r: Float, var speed: Float, var drift: Float)
    private val flakes = mutableListOf<Snowflake>()
    private var snowInitialized = false
    private val snowRunnable = object : Runnable {
        override fun run() {
            updateSnow()
            invalidate()
            fadeHandler.postDelayed(this, 40)
        }
    }

    // --- paints ---
    private val bgPaint = Paint()
    private val keyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#2A3A55") }
    private val specialKeyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#1C2740") }
    private val highlightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#5DA9FF") }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        textSize = 46f
    }
    private val snowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; alpha = 220 }

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null) // для гладких теней/градиентов на старых устройствах
        startSnow()
    }

    fun setShifted(value: Boolean) {
        shifted = value
        rows = if (symbolsMode) KeyboardLayout.symbolRows() else KeyboardLayout.russianRows(shifted)
        requestLayout()
        invalidate()
    }

    fun toggleSymbols(show: Boolean) {
        symbolsMode = show
        rows = if (symbolsMode) KeyboardLayout.symbolRows() else KeyboardLayout.russianRows(shifted)
        requestLayout()
        invalidate()
    }

    private fun startSnow() {
        fadeHandler.removeCallbacks(snowRunnable)
        fadeHandler.post(snowRunnable)
    }

    private fun ensureSnow(w: Int, h: Int) {
        if (snowInitialized) return
        flakes.clear()
        val count = 45
        repeat(count) {
            flakes.add(
                Snowflake(
                    x = Random.nextFloat() * w,
                    y = Random.nextFloat() * h,
                    r = 2f + Random.nextFloat() * 4f,
                    speed = 0.6f + Random.nextFloat() * 1.6f,
                    drift = (Random.nextFloat() - 0.5f) * 1.2f
                )
            )
        }
        snowInitialized = true
    }

    private fun updateSnow() {
        val w = width
        val h = height
        if (w == 0 || h == 0) return
        ensureSnow(w, h)
        for (f in flakes) {
            f.y += f.speed
            f.x += f.drift
            if (f.y > h) {
                f.y = -5f
                f.x = Random.nextFloat() * w
            }
            if (f.x < 0) f.x = w.toFloat()
            if (f.x > w) f.x = 0f
        }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val rowHeight = 130
        val h = rowHeight * rows.size
        setMeasuredDimension(w, h)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        layoutKeys(w, h)
        snowInitialized = false
    }

    private fun layoutKeys(w: Int, h: Int) {
        val rowHeight = h / rows.size.toFloat()
        val padding = 6f
        val result = mutableListOf<List<KeyRect>>()
        for ((rowIndex, row) in rows.withIndex()) {
            val totalWeight = row.sumOf { it.widthWeight.toDouble() }.toFloat()
            var x = 0f
            val top = rowIndex * rowHeight + padding
            val bottom = (rowIndex + 1) * rowHeight - padding
            val rowRects = mutableListOf<KeyRect>()
            for (key in row) {
                val keyWidth = (key.widthWeight / totalWeight) * w
                val rect = RectF(x + padding, top, x + keyWidth - padding, bottom)
                rowRects.add(KeyRect(key, rect))
                x += keyWidth
            }
            result.add(rowRects)
        }
        keyRects = result
    }

    override fun onDraw(canvas: Canvas) {
        val w = width
        val h = height

        // фон — ночной градиент под снегопад
        bgPaint.shader = LinearGradient(
            0f, 0f, 0f, h.toFloat(),
            Color.parseColor("#0F1B33"), Color.parseColor("#1B2A4A"),
            Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), bgPaint)

        // снег
        for (f in flakes) {
            canvas.drawCircle(f.x, f.y, f.r, snowPaint)
        }

        // клавиши
        for (row in keyRects) {
            for (kr in row) {
                val paint = if (kr.key.isSpecial) specialKeyPaint else keyPaint
                canvas.drawRoundRect(kr.rect, 18f, 18f, paint)

                val alpha = pressedAlpha[kr.key]
                if (alpha != null && alpha > 0) {
                    highlightPaint.alpha = alpha
                    canvas.drawRoundRect(kr.rect, 18f, 18f, highlightPaint)
                }

                val label = displayLabel(kr.key)
                val textY = kr.rect.centerY() - (textPaint.descent() + textPaint.ascent()) / 2
                canvas.drawText(label, kr.rect.centerX(), textY, textPaint)
            }
        }
    }

    private fun displayLabel(key: Key): String {
        if (key.code == KeyCode.SHIFT) return if (shifted) "⇧" else "⇧"
        return key.label
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                val kr = findKeyAt(event.x, event.y) ?: return true
                highlightKey(kr.key)
                performClick()
                listener?.onKeyPressed(kr.key)
            }
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    private fun findKeyAt(x: Float, y: Float): KeyRect? {
        for (row in keyRects) {
            for (kr in row) {
                if (kr.rect.contains(x, y)) return kr
            }
        }
        return null
    }

    /** Подсветка нажатой клавиши с плавным затуханием. */
    private fun highlightKey(key: Key) {
        pressedAlpha[key] = 200
        invalidate()
        fadeHandler.postDelayed(object : Runnable {
            var alpha = 200
            override fun run() {
                alpha -= 30
                pressedAlpha[key] = alpha.coerceAtLeast(0)
                invalidate()
                if (alpha > 0) fadeHandler.postDelayed(this, 16)
                else pressedAlpha.remove(key)
            }
        }, 16)
    }

    fun stopAnimations() {
        fadeHandler.removeCallbacksAndMessages(null)
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        stopAnimations()
    }
}
